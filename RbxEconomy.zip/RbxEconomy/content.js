(function () {
  function parsePrice(text) {
    text = text.trim().replace(/\s/g, '').replace(/,/g, '');

    let multiplier = 1;
    if (text.endsWith('B')) {
      multiplier = 1_000_000_000;
      text = text.slice(0, -1);
    } else if (text.endsWith('M')) {
      multiplier = 1_000_000;
      text = text.slice(0, -1);
    } else if (text.endsWith('K')) {
      multiplier = 1_000;
      text = text.slice(0, -1);
    }

    const num = parseFloat(text);
    if (isNaN(num)) return null;
    return num * multiplier;
  }

  function formatShort(num) {
    if (num >= 1_000_000_000) {
      const v = num / 1_000_000_000;
      return (v % 1 === 0 ? v.toFixed(0) : v.toFixed(1).replace(/\.0$/, '')) + 'B';
    }
    if (num >= 1_000_000) {
      const v = num / 1_000_000;
      return (v % 1 === 0 ? v.toFixed(0) : v.toFixed(1).replace(/\.0$/, '')) + 'M';
    }
    if (num >= 1_000) {
      const v = num / 1_000;
      return (v % 1 === 0 ? v.toFixed(0) : v.toFixed(1).replace(/\.0$/, '')) + 'K';
    }
    return num.toFixed(0);
  }

  function addDiscountBadges() {
    const prices = document.querySelectorAll('.text-robux-tile');
    prices.forEach((el) => {
      if (el.dataset.discountAdded) return;
      const txt = el.textContent.trim().toLowerCase();
      if (txt === 'free' || txt === '0') return;
      el.dataset.discountAdded = '1';

      const original = parsePrice(el.textContent);
      if (original === null) return;

      const discount = Math.round(original * 0.4);
      const badge = document.createElement('span');
      badge.textContent = '-' + formatShort(discount);
      badge.style.cssText =
        'display:inline-block;margin-left:6px;padding:2px 6px;' +
        'font-size:11px;font-weight:600;border-radius:4px;' +
        'background:#7b2d8e;color:#e0b0ff;white-space:nowrap;';
      el.appendChild(badge);
    });
  }

  function addDiscountToItemPage() {
    const priceEl = document.querySelector('.item-price-value .text');
    if (priceEl && !priceEl.dataset.discountAdded) {
      const txt = priceEl.textContent.trim().toLowerCase();
      if (txt === 'free' || txt === '0') return;
      priceEl.dataset.discountAdded = '1';
      const original = parsePrice(priceEl.textContent);
      if (original !== null) {
        const discount = Math.round(original * 0.4);
        const badge = document.createElement('span');
        badge.textContent = ' -' + formatShort(discount);
        badge.style.cssText =
          'display:inline-block;margin-left:6px;padding:2px 6px;' +
          'font-size:11px;font-weight:600;border-radius:4px;' +
          'background:#7b2d8e;color:#e0b0ff;white-space:nowrap;';
        priceEl.appendChild(badge);
      }
    }
  }

  function addDiscountToLargeRobux() {
    const robuxLg = document.querySelectorAll('.text-robux-lg');
    robuxLg.forEach((el) => {
      if (el.dataset.discountAdded) return;
      const txt = el.textContent.trim().toLowerCase();
      if (txt === 'free' || txt === '0') return;
      el.dataset.discountAdded = '1';
      const original = parsePrice(el.textContent);
      if (original !== null) {
        const discount = Math.round(original * 0.4);
        const badge = document.createElement('span');
        badge.textContent = ' -' + formatShort(discount);
        badge.style.cssText =
          'display:inline-block;margin-left:6px;padding:2px 6px;' +
          'font-size:11px;font-weight:600;border-radius:4px;' +
          'background:#7b2d8e;color:#e0b0ff;white-space:nowrap;';
        el.appendChild(badge);
      }
    });
  }

  function addDiscountToTextRobux() {
    const els = document.querySelectorAll('.text-robux');
    els.forEach((el) => {
      if (el.classList.contains('ml-1') || el.classList.contains('text-body-medium')) return;
      if (el.dataset.discountAdded) return;
      const txt = el.textContent.trim().toLowerCase();
      if (txt === 'free' || txt === '0') return;
      el.dataset.discountAdded = '1';
      const original = parsePrice(el.textContent);
      if (original !== null) {
        const discount = Math.round(original * 0.4);
        const badge = document.createElement('span');
        badge.textContent = ' -' + formatShort(discount);
        badge.style.cssText =
          'display:inline-block;margin-left:6px;padding:2px 6px;' +
          'font-size:11px;font-weight:600;border-radius:4px;' +
          'background:#7b2d8e;color:#e0b0ff;white-space:nowrap;';
        el.appendChild(badge);
      }
    });
  }

  let savedItemPrice = null;

  function captureItemPrice() {
    savedItemPrice = null;
    const priceEl = document.querySelector('.item-price-value .text');
    if (priceEl) {
      const txt = priceEl.textContent.trim().toLowerCase();
      if (txt !== 'free' && txt !== '0') {
        savedItemPrice = parsePrice(priceEl.textContent);
      }
    }
    const robuxLg = document.querySelector('.text-robux-lg');
    if (robuxLg) {
      const txt = robuxLg.textContent.trim().toLowerCase();
      if (txt !== 'free' && txt !== '0') {
        savedItemPrice = parsePrice(robuxLg.textContent);
      }
    }
  }

  function addDiscountToPurchaseModal() {
    const modalBody = document.querySelector('#unified-purchase-completion-modal-body');
    if (modalBody && !modalBody.dataset.discountAdded) {
      modalBody.dataset.discountAdded = '1';
      const allText = modalBody.textContent.toLowerCase();
      if (allText.includes('free')) return;
      if (savedItemPrice === null || savedItemPrice === 0 || isNaN(savedItemPrice)) return;
      const discount = Math.round(savedItemPrice * 0.4);
      const banner = document.createElement('div');
      banner.textContent = 'Your ' + discount + ' Robux will arrive in 2 days';
      banner.style.cssText =
        'color:#2ecc71;font-size:13px;font-weight:600;margin-bottom:12px;';
      modalBody.insertBefore(banner, modalBody.firstChild);
    }
  }

  function runAllDiscounts() {
    captureItemPrice();
    addDiscountBadges();
    addDiscountToItemPage();
    addDiscountToLargeRobux();
    addDiscountToTextRobux();
    addDiscountToPurchaseModal();
  }

  runAllDiscounts();

  const observer = new MutationObserver(runAllDiscounts);
  observer.observe(document.body, { childList: true, subtree: true });

  // Welcome popup for first-time users
  chrome.storage.local.get('economExtensionSeen', (data) => {
    if (data.economExtensionSeen) return;

    function showWelcomePopup() {
      const overlay = document.createElement('div');
      overlay.id = 'econom-welcome-overlay';
      overlay.style.cssText =
        'position:fixed;top:0;left:0;width:100%;height:100%;' +
        'background:rgba(0,0,0,0.7);z-index:999999;display:flex;' +
        'align-items:center;justify-content:center;font-family:Arial,sans-serif;';

      const popup = document.createElement('div');
      popup.style.cssText =
        'background:#1a1a2e;border-radius:16px;padding:30px 40px;' +
        'text-align:center;box-shadow:0 8px 32px rgba(0,0,0,0.5);' +
        'border:2px solid #7b2d8e;min-width:320px;';

      const title = document.createElement('div');
      title.textContent = 'Did someone invited you?';
      title.style.cssText =
        'color:#fff;font-size:18px;font-weight:700;margin-bottom:24px;';

      const btnRow = document.createElement('div');
      btnRow.style.cssText = 'display:flex;gap:16px;justify-content:center;';

      function makeBtn(text, color, onClick) {
        const btn = document.createElement('button');
        btn.textContent = text;
        btn.style.cssText =
          'padding:10px 32px;font-size:15px;font-weight:700;border:none;' +
          'border-radius:8px;cursor:pointer;color:#fff;background:' + color + ';' +
          'transition:opacity 0.2s;';
        btn.onmouseenter = () => btn.style.opacity = '0.85';
        btn.onmouseleave = () => btn.style.opacity = '1';
        btn.onclick = onClick;
        return btn;
      }

      btnRow.appendChild(makeBtn('No', '#555', () => {
        overlay.remove();
        chrome.storage.local.set({ economExtensionSeen: true });
      }));

      btnRow.appendChild(makeBtn('Yes', '#7b2d8e', () => {
        overlay.remove();
        showInviteMenu();
      }));

      popup.appendChild(title);
      popup.appendChild(btnRow);
      overlay.appendChild(popup);
      document.body.appendChild(overlay);
    }

    function showInviteMenu() {
      const overlay = document.createElement('div');
      overlay.id = 'econom-invite-overlay';
      overlay.style.cssText =
        'position:fixed;top:0;left:0;width:100%;height:100%;' +
        'background:rgba(0,0,0,0.7);z-index:999999;display:flex;' +
        'align-items:center;justify-content:center;font-family:Arial,sans-serif;';

      const popup = document.createElement('div');
      popup.style.cssText =
        'background:#1a1a2e;border-radius:16px;padding:30px;' +
        'box-shadow:0 8px 32px rgba(0,0,0,0.5);border:2px solid #7b2d8e;' +
        'width:420px;position:relative;';

      const closeBtn = document.createElement('div');
      closeBtn.textContent = '\u00D7';
      closeBtn.style.cssText =
        'position:absolute;top:12px;right:16px;font-size:24px;color:#888;' +
        'cursor:pointer;line-height:1;';
      closeBtn.onclick = () => {
        overlay.remove();
        chrome.storage.local.set({ economExtensionSeen: true });
      };

      const contentRow = document.createElement('div');
      contentRow.style.cssText = 'display:flex;gap:20px;align-items:center;margin-bottom:20px;';

      // Avatar placeholder (left side)
      const avatarWrap = document.createElement('div');
      avatarWrap.style.cssText =
        'width:100px;height:100px;border-radius:50%;background:#2a2a3e;' +
        'display:flex;align-items:center;justify-content:center;flex-shrink:0;' +
        'overflow:hidden;border:3px solid #7b2d8e;';
      const avatarImg = document.createElement('img');
      avatarImg.style.cssText = 'width:100%;height:100%;object-fit:cover;display:none;';
      const avatarPlaceholder = document.createElement('div');
      avatarPlaceholder.textContent = '?';
      avatarPlaceholder.style.cssText = 'color:#555;font-size:36px;font-weight:700;';
      avatarWrap.appendChild(avatarImg);
      avatarWrap.appendChild(avatarPlaceholder);

      // Input area (right side)
      const inputArea = document.createElement('div');
      inputArea.style.cssText = 'flex:1;display:flex;flex-direction:column;gap:8px;';

      const inputLabel = document.createElement('div');
      inputLabel.textContent = 'Enter username:';
      inputLabel.style.cssText = 'color:#aaa;font-size:13px;';

      const usernameInput = document.createElement('input');
      usernameInput.type = 'text';
      usernameInput.placeholder = 'Roblox username';
      usernameInput.style.cssText =
        'padding:10px 12px;font-size:14px;border-radius:8px;border:1px solid #444;' +
        'background:#0f0f1e;color:#fff;outline:none;width:100%;box-sizing:border-box;';
      usernameInput.onfocus = () => usernameInput.style.borderColor = '#7b2d8e';
      usernameInput.onblur = () => usernameInput.style.borderColor = '#444';

      const statusText = document.createElement('div');
      statusText.style.cssText = 'color:#888;font-size:12px;min-height:16px;';

      inputArea.appendChild(inputLabel);
      inputArea.appendChild(usernameInput);
      inputArea.appendChild(statusText);

      contentRow.appendChild(avatarWrap);
      contentRow.appendChild(inputArea);

      // Accept button
      const acceptBtn = document.createElement('button');
      acceptBtn.textContent = 'Accept';
      acceptBtn.style.cssText =
        'width:100%;padding:12px;font-size:15px;font-weight:700;border:none;' +
        'border-radius:8px;cursor:pointer;color:#fff;background:#7b2d8e;' +
        'transition:opacity 0.2s;opacity:0.4;pointer-events:none;';
      acceptBtn.onmouseenter = () => { if (acceptBtn.style.pointerEvents !== 'none') acceptBtn.style.opacity = '0.85'; };
      acceptBtn.onmouseleave = () => { if (acceptBtn.style.pointerEvents !== 'none') acceptBtn.style.opacity = '1'; };

      let currentUserId = null;

      function enableAccept() {
        acceptBtn.style.opacity = '1';
        acceptBtn.style.pointerEvents = 'auto';
      }

      let fetchTimeout = null;
      usernameInput.addEventListener('input', () => {
        clearTimeout(fetchTimeout);
        const username = usernameInput.value.trim();
        if (username.length < 3) {
          avatarImg.style.display = 'none';
          avatarPlaceholder.style.display = '';
          statusText.textContent = '';
          currentUserId = null;
          acceptBtn.style.opacity = '0.4';
          acceptBtn.style.pointerEvents = 'none';
          return;
        }

        statusText.textContent = 'Searching...';
        statusText.style.color = '#888';
        avatarImg.style.display = 'none';
        avatarPlaceholder.style.display = '';
        currentUserId = null;
        acceptBtn.style.opacity = '0.4';
        acceptBtn.style.pointerEvents = 'none';

        fetchTimeout = setTimeout(() => {
          fetch('https://users.roblox.com/v1/usernames/users', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ usernames: [username] })
          })
            .then(r => r.json())
            .then(data => {
              if (!data.data || data.data.length === 0) {
                statusText.textContent = 'User not found';
                statusText.style.color = '#e74c3c';
                return;
              }
              const user = data.data[0];
              currentUserId = user.id;
              statusText.textContent = 'Found: ' + user.displayName + ' (@' + user.name + ')';
              statusText.style.color = '#2ecc71';

              return fetch(
                'https://thumbnails.roblox.com/v1/users/avatar-headshot?userIds=' + user.id + '&size=420x420&format=Png&isCircular=false'
              );
            })
            .then(r => r ? r.json() : null)
            .then(thumbData => {
              if (!thumbData || !thumbData.data || thumbData.data.length === 0) return;
              const img = thumbData.data[0].imageUrl;
              avatarImg.src = img;
              avatarImg.style.display = 'block';
              avatarPlaceholder.style.display = 'none';
              enableAccept();
            })
            .catch(() => {
              statusText.textContent = 'Error fetching user';
              statusText.style.color = '#e74c3c';
            });
        }, 500);
      });

      acceptBtn.onclick = () => {
        if (!currentUserId) return;
        popup.remove();

        const notif = document.createElement('div');
        notif.style.cssText =
          'position:fixed;top:50%;left:50%;transform:translate(-50%,-50%);' +
          'background:#1a1a2e;border:2px solid #2ecc71;border-radius:12px;' +
          'padding:24px 32px;text-align:center;z-index:1000000;' +
          'box-shadow:0 8px 32px rgba(0,0,0,0.5);font-family:Arial,sans-serif;';

        const notifText = document.createElement('div');
        notifText.textContent = 'You will receive 80 Robux in 2 days!';
        notifText.style.cssText = 'color:#fff;font-size:16px;font-weight:700;margin-bottom:8px;';

        const notifSub = document.createElement('div');
        notifSub.textContent = 'Thank you for using RbxEconomy';
        notifSub.style.cssText = 'color:#aaa;font-size:13px;';

        notif.appendChild(notifText);
        notif.appendChild(notifSub);
        document.body.appendChild(notif);

        setTimeout(() => {
          notif.remove();
          overlay.remove();
          chrome.storage.local.set({ economExtensionSeen: true });
        }, 2000);
      };

      popup.appendChild(closeBtn);
      popup.appendChild(contentRow);
      popup.appendChild(acceptBtn);
      overlay.appendChild(popup);
      document.body.appendChild(overlay);
    }

    showWelcomePopup();
  });
})();
